<div>
    <img alt="Under Construction" src="img/construction.gif"/>
</div>
<div>
    <a href="logout.php">Log Out</a>
</div>
